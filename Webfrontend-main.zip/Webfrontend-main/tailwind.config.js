module.exports = {
  theme: {
    extend: {
      inset: {
        '2': '2px',
      }
    }
  },
  variants: {},
  plugins: []
}
