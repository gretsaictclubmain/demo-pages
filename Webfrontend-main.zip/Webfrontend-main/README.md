# Webfrontend
For all those participating in the frontend part kindly use the tailwind.css file. 
Everything has already been set up you'll just import the classes.
